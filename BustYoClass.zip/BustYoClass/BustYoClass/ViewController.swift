//
//  ViewController.swift
//  BustYoClass
//
//  Created by Boris Huang on 11/10/18.
//  Copyright © 2018 Boris Huang. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var txtUsername: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var butLogin: UIButton!
    @IBOutlet weak var butSignup: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        txtUsername.layer.borderWidth = 1
        txtUsername.layer.borderColor  = UIColor.white.cgColor
        txtUsername.layer.cornerRadius = 20
        txtUsername.clipsToBounds = true
        
        txtPassword.layer.borderWidth = 1
        txtPassword.layer.borderColor  = UIColor.white.cgColor
        txtPassword.layer.cornerRadius = 20
        txtPassword.clipsToBounds = true
        
        butLogin.layer.cornerRadius = 20
        butLogin.clipsToBounds = true
        
        butSignup.layer.cornerRadius = 20
        butSignup.clipsToBounds = true
        
    }


}

